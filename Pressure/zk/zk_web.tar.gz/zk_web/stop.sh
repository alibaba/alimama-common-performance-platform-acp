
pid=`ps xf | grep "js" | grep -v grep  | awk '{print $1}' |xargs -i kill -9 {} `
