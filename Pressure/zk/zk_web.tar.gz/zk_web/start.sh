export PATH=$PATH:$(dirname $0)/nodejs/bin/
export NODE_PATH=$(dirname $0)/nodejs:$(dirname $0)/nodejs/lib/node_modules
LOGFILE=$(dirname $0)/logs/node-zk-browser.log
nohup node $(dirname $0)/app.js 2>&1 >>$LOGFILE &
